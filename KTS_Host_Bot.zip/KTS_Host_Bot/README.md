# KTS Host Bot

Slash-command-only Discord bot for KTS Host / LuxaNodes.

## Features
- Admin and moderation
- Anti-nuke / anti-raid configuration
- Tickets
- Giveaways
- Host monitoring
- Website and Minecraft monitoring
- VPS management hooks
- Welcome/auto-role automation
- Community utilities
- Statistics
- SQLite persistence

## Install

```bash
python -m venv venv
# Linux:
source venv/bin/activate
# Windows:
venv\Scripts\activate

pip install -r requirements.txt
copy .env.example .env
```

Put your bot token in `.env`, then:

```bash
python bot.py
```

All commands are `/` slash commands.

## Important
The VPS/Pterodactyl/Proxmox commands are deliberately permission-gated and use service adapters. Add your real API credentials before enabling destructive actions.
