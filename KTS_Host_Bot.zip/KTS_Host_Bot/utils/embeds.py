import discord

def success(title, description):
    return discord.Embed(
        title=f"✅ {title}",
        description=description,
        color=discord.Color.green()
    )

def error(title, description):
    return discord.Embed(
        title=f"❌ {title}",
        description=description,
        color=discord.Color.red()
    )

def info(title, description):
    return discord.Embed(
        title=f"ℹ️ {title}",
        description=description,
        color=discord.Color.blurple()
    )

def warning(title, description):
    return discord.Embed(
        title=f"⚠️ {title}",
        description=description,
        color=discord.Color.orange()
    )
