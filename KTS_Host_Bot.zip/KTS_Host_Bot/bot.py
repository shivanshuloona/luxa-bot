import os
import asyncio
import logging
import discord
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
GUILD_ID = os.getenv("GUILD_ID")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s"
)
log = logging.getLogger("kts-bot")

INTENTS = discord.Intents.default()
INTENTS.members = True
INTENTS.message_content = False

class KTSBot(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix=commands.when_mentioned,
            intents=INTENTS,
            help_command=None,
            case_insensitive=True,
        )

    async def setup_hook(self):
        from services.database import init_db
        await init_db()
        extensions = [
            "cogs.help",
            "cogs.admin",
            "cogs.moderation",
            "cogs.security",
            "cogs.tickets",
            "cogs.giveaways",
            "cogs.host",
            "cogs.community",
            "cogs.automation",
            "cogs.utility",
            "cogs.vps",
            "cogs.stats",
        ]
        for ext in extensions:
            try:
                await self.load_extension(ext)
                log.info("Loaded %s", ext)
            except Exception:
                log.exception("Failed to load %s", ext)

        if GUILD_ID:
            guild = discord.Object(id=int(GUILD_ID))
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            log.info("Synced %d guild commands", len(synced))
        else:
            synced = await self.tree.sync()
            log.info("Synced %d global commands", len(synced))

    async def on_ready(self):
        log.info("Logged in as %s (%s)", self.user, self.user.id)
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="/help | KTS Host"
            )
        )

bot = KTSBot()

@bot.tree.command(name="ping", description="Check bot latency.")
async def ping(interaction: discord.Interaction):
    await interaction.response.send_message(
        f"🏓 Pong! `{round(bot.latency * 1000)}ms`"
    )

if not TOKEN:
    raise RuntimeError("DISCORD_TOKEN is missing from .env")

bot.run(TOKEN)
