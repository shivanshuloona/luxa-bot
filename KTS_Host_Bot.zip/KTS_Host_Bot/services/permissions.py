import discord

def is_staff(member: discord.Member) -> bool:
    return member.guild_permissions.manage_guild or member.guild_permissions.moderate_members

def is_admin(member: discord.Member) -> bool:
    return member.guild_permissions.administrator

def bot_can(member: discord.Member, permission: str) -> bool:
    return getattr(member.guild_permissions, permission, False)
