import time
import aiohttp

async def http_check(url: str, timeout: int = 10):
    started = time.perf_counter()
    try:
        timeout_cfg = aiohttp.ClientTimeout(total=timeout)
        async with aiohttp.ClientSession(timeout=timeout_cfg) as session:
            async with session.get(url, allow_redirects=True) as response:
                await response.read()
                latency = (time.perf_counter() - started) * 1000
                return True, response.status, round(latency, 2)
    except Exception:
        return False, 0, None
