import discord
from discord.ext import commands
from discord import app_commands

class Community(commands.GroupCog, group_name="community"):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="avatar", description="Show a user's avatar.")
    async def avatar(self, interaction, member: discord.Member = None):
        member = member or interaction.user
        e = discord.Embed(title=f"{member}'s Avatar")
        e.set_image(url=member.display_avatar.url)
        await interaction.response.send_message(embed=e)

    @app_commands.command(name="serverinfo", description="Show server information.")
    async def serverinfo(self, interaction):
        g = interaction.guild
        e = discord.Embed(title=f"📊 {g.name}", color=discord.Color.blurple())
        e.add_field(name="Members", value=str(g.member_count))
        e.add_field(name="Channels", value=str(len(g.channels)))
        e.add_field(name="Roles", value=str(len(g.roles)))
        e.add_field(name="Owner", value=g.owner.mention if g.owner else "Unknown")
        await interaction.response.send_message(embed=e)

    @app_commands.command(name="poll", description="Create a simple yes/no poll.")
    async def poll(self, interaction, question: str):
        await interaction.response.send_message(f"📊 **Poll**\n{question}\n\n👍 Yes\n👎 No")
        msg = await interaction.original_response()
        await msg.add_reaction("👍")
        await msg.add_reaction("👎")

    @app_commands.command(name="suggest", description="Send a suggestion.")
    async def suggest(self, interaction, suggestion: str):
        e = discord.Embed(title="💡 New Suggestion", description=suggestion)
        e.set_author(name=str(interaction.user), icon_url=interaction.user.display_avatar.url)
        await interaction.channel.send(embed=e)
        await interaction.response.send_message("Suggestion submitted.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Community(bot))
