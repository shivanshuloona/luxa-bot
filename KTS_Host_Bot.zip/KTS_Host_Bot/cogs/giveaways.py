import discord
from discord.ext import commands
from discord import app_commands
import random
from datetime import datetime, timezone, timedelta

class GiveawayView(discord.ui.View):
    def __init__(self, cog):
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(label="Enter", emoji="🎉", style=discord.ButtonStyle.green, custom_id="kts:giveaway_enter")
    async def enter(self, interaction, button):
        key = interaction.message.id
        self.cog.entries.setdefault(key, set()).add(interaction.user.id)
        await interaction.response.send_message("You entered the giveaway! 🎉", ephemeral=True)

class Giveaways(commands.GroupCog, group_name="giveaway"):
    def __init__(self, bot):
        self.bot = bot
        self.entries = {}

    @app_commands.command(name="start", description="Start a giveaway.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def start(self, interaction, duration_minutes: app_commands.Range[int, 1, 10080], winners: app_commands.Range[int, 1, 50], prize: str):
        ends = datetime.now(timezone.utc) + timedelta(minutes=duration_minutes)
        embed = discord.Embed(title="🎉 GIVEAWAY", description=f"**{prize}**\n\nWinners: `{winners}`\nEnds: <t:{int(ends.timestamp())}:R>", color=discord.Color.gold())
        await interaction.response.send_message("Giveaway started.")
        msg = await interaction.channel.send(embed=embed, view=GiveawayView(self))
        self.entries[msg.id] = set()
        await discord.utils.sleep_until(ends)
        users = list(self.entries.get(msg.id, set()))
        selected = random.sample(users, min(winners, len(users))) if users else []
        result = ", ".join(f"<@{u}>" for u in selected) if selected else "No valid entries."
        await interaction.channel.send(f"🎉 Giveaway ended for **{prize}**!\nWinners: {result}")

async def setup(bot):
    cog = Giveaways(bot)
    await bot.add_cog(cog)
    bot.add_view(GiveawayView(cog))
