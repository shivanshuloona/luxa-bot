import discord
from discord.ext import commands
from discord import app_commands

class Security(commands.GroupCog, group_name="security"):
    def __init__(self, bot):
        self.bot = bot
        self.config = {}

    @app_commands.command(name="antinuke", description="Enable/disable anti-nuke protection.")
    @app_commands.describe(enabled="Whether protection is enabled")
    @app_commands.checks.has_permissions(administrator=True)
    async def antinuke(self, interaction, enabled: bool):
        self.config[(interaction.guild.id, "antinuke")] = enabled
        state = "enabled" if enabled else "disabled"
        await interaction.response.send_message(f"🛡️ Anti-nuke **{state}**.")

    @app_commands.command(name="antiraid", description="Enable/disable anti-raid protection.")
    @app_commands.checks.has_permissions(administrator=True)
    async def antiraid(self, interaction, enabled: bool):
        self.config[(interaction.guild.id, "antiraid")] = enabled
        state = "enabled" if enabled else "disabled"
        await interaction.response.send_message(f"🚨 Anti-raid **{state}**.")

async def setup(bot):
    await bot.add_cog(Security(bot))
