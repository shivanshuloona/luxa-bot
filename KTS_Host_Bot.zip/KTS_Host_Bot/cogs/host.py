import discord
from discord.ext import commands
from discord import app_commands
from services.monitor import http_check
from services.database import execute, fetchall
from utils.embeds import success, error

class Host(commands.GroupCog, group_name="monitor"):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="check", description="Check a website right now.")
    async def check(self, interaction, url: str):
        await interaction.response.defer()
        ok, status, latency = await http_check(url)
        if ok:
            await interaction.followup.send(embed=success("Host Online", f"URL: `{url}`\nHTTP: `{status}`\nLatency: `{latency}ms`"))
        else:
            await interaction.followup.send(embed=error("Host Offline", f"Could not reach `{url}`."))

    @app_commands.command(name="add", description="Add a website monitor.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def add(self, interaction, name: str, url: str):
        await execute(
            "INSERT INTO monitors(guild_id,name,url,channel_id) VALUES(?,?,?,?)",
            (interaction.guild.id, name, url, interaction.channel.id)
        )
        await interaction.response.send_message(embed=success("Monitor Added", f"`{name}` → `{url}`"))

    @app_commands.command(name="list", description="List configured monitors.")
    async def list(self, interaction):
        rows = await fetchall("SELECT name,url,enabled FROM monitors WHERE guild_id=?", (interaction.guild.id,))
        if not rows:
            return await interaction.response.send_message("No monitors configured.")
        text = "\n".join(f"• **{n}** — `{u}` — {'ON' if e else 'OFF'}" for n,u,e in rows)
        await interaction.response.send_message(embed=discord.Embed(title="🌐 Host Monitors", description=text))

async def setup(bot):
    await bot.add_cog(Host(bot))
