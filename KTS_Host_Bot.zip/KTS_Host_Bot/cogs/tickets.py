import discord
from datetime import timedelta
from discord.ext import commands
from discord import app_commands
from services.database import execute

class TicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Create Ticket", emoji="🎫", style=discord.ButtonStyle.green, custom_id="kts:create_ticket")
    async def create(self, interaction: discord.Interaction, button: discord.ui.Button):
        guild = interaction.guild
        existing = discord.utils.get(guild.text_channels, name=f"ticket-{interaction.user.id}")
        if existing:
            return await interaction.response.send_message(f"You already have {existing.mention}.", ephemeral=True)
        channel = await guild.create_text_channel(
            f"ticket-{interaction.user.id}",
            reason=f"Ticket opened by {interaction.user}"
        )
        await channel.set_permissions(guild.default_role, view_channel=False)
        await channel.set_permissions(interaction.user, view_channel=True, send_messages=True)
        await execute(
            "INSERT INTO tickets(channel_id,guild_id,opener_id) VALUES(?,?,?)",
            (channel.id, guild.id, interaction.user.id)
        )
        await channel.send(
            f"{interaction.user.mention} welcome! Staff will assist you here.\n"
            "Use `/ticket close` when finished."
        )
        await interaction.response.send_message(f"🎫 Created {channel.mention}", ephemeral=True)

class Tickets(commands.GroupCog, group_name="ticket"):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="setup", description="Create a ticket panel.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def setup_panel(self, interaction):
        embed = discord.Embed(
            title="🎫 KTS Host Support",
            description="Press the button below to open a support ticket.",
            color=discord.Color.blurple()
        )
        await interaction.channel.send(embed=embed, view=TicketView())
        await interaction.response.send_message("Ticket panel created.", ephemeral=True)

    @app_commands.command(name="close", description="Close the current ticket.")
    async def close(self, interaction):
        if not interaction.channel.name.startswith("ticket-"):
            return await interaction.response.send_message("This is not a ticket channel.", ephemeral=True)
        await interaction.response.send_message("🔒 Closing ticket in 5 seconds.")
        await discord.utils.sleep_until(discord.utils.utcnow() + timedelta(seconds=5))
        await interaction.channel.delete(reason=f"Closed by {interaction.user}")

async def setup(bot):
    await bot.add_cog(Tickets(bot))
    bot.add_view(TicketView())
