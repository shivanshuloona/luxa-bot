import discord
from discord.ext import commands
from discord import app_commands

class Stats(commands.GroupCog, group_name="stats"):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="overview", description="Show server statistics.")
    async def overview(self, interaction):
        g = interaction.guild
        text = (
            f"👥 Members: `{g.member_count}`\n"
            f"💬 Channels: `{len(g.channels)}`\n"
            f"🎭 Roles: `{len(g.roles)}`\n"
            f"😀 Emojis: `{len(g.emojis)}`\n"
            f"🚀 Boosts: `{g.premium_subscription_count}`"
        )
        await interaction.response.send_message(embed=discord.Embed(title="📊 Server Statistics", description=text))

async def setup(bot):
    await bot.add_cog(Stats(bot))
