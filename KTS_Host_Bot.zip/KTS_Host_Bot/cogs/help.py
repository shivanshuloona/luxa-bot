import discord
from discord.ext import commands
from discord import app_commands

class Help(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="help", description="Open the KTS Bot help menu.")
    async def help(self, interaction: discord.Interaction):
        e = discord.Embed(
            title="📖 KTS Host Bot Help",
            description="Slash-command-only management bot.",
            color=discord.Color.blurple()
        )
        e.add_field(name="🛠️ Admin", value="`/ban` `/kick` `/timeout` `/clear` `/lock`", inline=False)
        e.add_field(name="🛡️ Security", value="`/security antinuke` `/security antiraid`", inline=False)
        e.add_field(name="🎫 Tickets", value="`/ticket setup` `/ticket close` `/ticket claim`", inline=False)
        e.add_field(name="🌐 Host", value="`/monitor add` `/monitor list` `/status`", inline=False)
        e.add_field(name="🎉 Giveaways", value="`/giveaway start` `/giveaway end` `/giveaway reroll`", inline=False)
        e.add_field(name="💻 VPS", value="`/vps info` `/vps status`", inline=False)
        e.add_field(name="⭐ Community", value="`/avatar` `/serverinfo` `/poll` `/suggest`", inline=False)
        e.set_footer(text="KTS Host • Use /help for commands")
        await interaction.response.send_message(embed=e)

async def setup(bot):
    await bot.add_cog(Help(bot))
