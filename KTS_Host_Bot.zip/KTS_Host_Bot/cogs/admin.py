import discord
from discord.ext import commands
from discord import app_commands
from utils.embeds import success, error

class Admin(commands.GroupCog, group_name="admin"):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="lock", description="Lock the current channel.")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def lock(self, interaction):
        overwrite = interaction.channel.overwrites_for(interaction.guild.default_role)
        overwrite.send_messages = False
        await interaction.channel.set_permissions(interaction.guild.default_role, overwrite=overwrite)
        await interaction.response.send_message(embed=success("Channel Locked", "This channel is now locked."))

    @app_commands.command(name="unlock", description="Unlock the current channel.")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def unlock(self, interaction):
        overwrite = interaction.channel.overwrites_for(interaction.guild.default_role)
        overwrite.send_messages = None
        await interaction.channel.set_permissions(interaction.guild.default_role, overwrite=overwrite)
        await interaction.response.send_message(embed=success("Channel Unlocked", "This channel is now unlocked."))

    @app_commands.command(name="slowmode", description="Set channel slowmode.")
    @app_commands.describe(seconds="Slowmode seconds, 0 disables it.")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def slowmode(self, interaction, seconds: app_commands.Range[int, 0, 21600]):
        await interaction.channel.edit(slowmode_delay=seconds)
        await interaction.response.send_message(embed=success("Slowmode Updated", f"Slowmode: `{seconds}s`"))

async def setup(bot):
    await bot.add_cog(Admin(bot))
