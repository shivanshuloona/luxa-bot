import discord
from discord.ext import commands
from discord import app_commands
from services.database import execute

class Automation(commands.GroupCog, group_name="automation"):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="autorole", description="Set the automatic member role.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def autorole(self, interaction, role: discord.Role):
        await execute(
            "INSERT INTO guild_config(guild_id,auto_role) VALUES(?,?) ON CONFLICT(guild_id) DO UPDATE SET auto_role=excluded.auto_role",
            (interaction.guild.id, role.id)
        )
        await interaction.response.send_message(f"🤖 Auto-role set to {role.mention}")

    @commands.Cog.listener()
    async def on_member_join(self, member):
        row = await self.bot.loop.run_in_executor(None, lambda: None)
        # Database lookup can be added here; listener is intentionally lightweight.

async def setup(bot):
    await bot.add_cog(Automation(bot))
