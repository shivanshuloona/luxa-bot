import discord
from discord.ext import commands
from discord import app_commands
import time

class Utility(commands.GroupCog, group_name="utility"):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="botinfo", description="Show bot information.")
    async def botinfo(self, interaction):
        e = discord.Embed(title="🤖 KTS Bot", color=discord.Color.blurple())
        e.add_field(name="Latency", value=f"{round(self.bot.latency*1000)}ms")
        e.add_field(name="Servers", value=str(len(self.bot.guilds)))
        e.add_field(name="Users", value=str(sum(g.member_count or 0 for g in self.bot.guilds)))
        await interaction.response.send_message(embed=e)

    @app_commands.command(name="say", description="Make the bot send text.")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def say(self, interaction, text: str):
        await interaction.channel.send(text)
        await interaction.response.send_message("Sent.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Utility(bot))
