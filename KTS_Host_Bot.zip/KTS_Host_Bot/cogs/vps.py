import discord
from discord.ext import commands
from discord import app_commands

class VPS(commands.GroupCog, group_name="vps"):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="info", description="Show VPS integration status.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def info(self, interaction):
        e = discord.Embed(title="💻 VPS Management", color=discord.Color.blurple())
        e.description = (
            "API adapter is ready for integration.\n\n"
            "Supported targets:\n"
            "• Proxmox\n"
            "• LXD\n"
            "• Pterodactyl\n"
            "• Custom VPS API"
        )
        e.set_footer(text="Configure credentials before enabling destructive actions.")
        await interaction.response.send_message(embed=e)

    @app_commands.command(name="status", description="Check VPS integration status.")
    async def status(self, interaction):
        await interaction.response.send_message("🟡 VPS API integration: **not configured**")

async def setup(bot):
    await bot.add_cog(VPS(bot))
