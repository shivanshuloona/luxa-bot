import discord
from datetime import timedelta
from discord.ext import commands
from discord import app_commands
from services.database import execute, fetchall
from utils.embeds import success, error

class Moderation(commands.GroupCog, group_name="mod"):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="ban", description="Ban a member.")
    @app_commands.describe(member="Member to ban", reason="Reason")
    @app_commands.checks.has_permissions(ban_members=True)
    async def ban(self, interaction, member: discord.Member, reason: str = "No reason provided"):
        if member.top_role >= interaction.user.top_role and interaction.user != interaction.guild.owner:
            return await interaction.response.send_message(embed=error("Permission", "You cannot ban this member."), ephemeral=True)
        await member.ban(reason=f"{interaction.user}: {reason}")
        await interaction.response.send_message(embed=success("Member Banned", f"{member.mention} was banned.\nReason: {reason}"))

    @app_commands.command(name="kick", description="Kick a member.")
    @app_commands.checks.has_permissions(kick_members=True)
    async def kick(self, interaction, member: discord.Member, reason: str = "No reason provided"):
        await member.kick(reason=f"{interaction.user}: {reason}")
        await interaction.response.send_message(embed=success("Member Kicked", f"{member.mention} was kicked."))

    @app_commands.command(name="timeout", description="Timeout a member.")
    @app_commands.describe(member="Member", minutes="Timeout duration in minutes")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def timeout(self, interaction, member: discord.Member, minutes: app_commands.Range[int, 1, 40320], reason: str = "No reason provided"):
        await member.timeout(discord.utils.utcnow() + timedelta(minutes=minutes), reason=reason)
        await interaction.response.send_message(embed=success("Timeout", f"{member.mention} timed out for `{minutes}` minutes."))

    @app_commands.command(name="clear", description="Delete messages.")
    @app_commands.describe(amount="Number of messages")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def clear(self, interaction, amount: app_commands.Range[int, 1, 100]):
        await interaction.response.defer(ephemeral=True)
        deleted = await interaction.channel.purge(limit=amount)
        await interaction.followup.send(f"🧹 Deleted `{len(deleted)}` messages.", ephemeral=True)

    @app_commands.command(name="warn", description="Warn a member.")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def warn(self, interaction, member: discord.Member, reason: str = "No reason provided"):
        await execute(
            "INSERT INTO warnings(guild_id,user_id,moderator_id,reason) VALUES(?,?,?,?)",
            (interaction.guild.id, member.id, interaction.user.id, reason)
        )
        await interaction.response.send_message(embed=success("Warning Added", f"{member.mention} warned.\nReason: {reason}"))

    @app_commands.command(name="warnings", description="View member warnings.")
    async def warnings(self, interaction, member: discord.Member):
        rows = await fetchall(
            "SELECT reason, moderator_id, created_at FROM warnings WHERE guild_id=? AND user_id=? ORDER BY id DESC",
            (interaction.guild.id, member.id)
        )
        if not rows:
            return await interaction.response.send_message("No warnings found.", ephemeral=True)
        text = "\n".join(f"• `{r[2]}` — <@{r[1]}> — {r[0]}" for r in rows[:15])
        await interaction.response.send_message(embed=discord.Embed(title=f"Warnings: {member}", description=text, color=discord.Color.orange()))

async def setup(bot):
    await bot.add_cog(Moderation(bot))
