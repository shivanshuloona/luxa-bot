# LuxaNodes Discord Bot

A production-oriented Discord bot starter for LuxaNodes.

## Included
- LuxaNodes branded embeds and banner
- Persistent ticket panel
- Invite tracking and reward points
- Giveaway creation
- Moderation commands
- Welcome messages
- Logging
- Hosting plans
- Website/Minecraft status checks
- Uptime monitor loop
- SQLite persistence
- Environment configuration
- Cog-based architecture
- Systemd deployment example

## Requirements
- Python 3.11+
- Discord bot token
- Message Content Intent enabled
- Server Members Intent enabled
- Invite/Moderation permissions as needed

## Install

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
python bot.py
```

## Linux service

```bash
sudo cp deploy/luxanodes.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now luxanodes
journalctl -u luxanodes -f
```

Never put your bot token directly into source code or publish `.env`.
