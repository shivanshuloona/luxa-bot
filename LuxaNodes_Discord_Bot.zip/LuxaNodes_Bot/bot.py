import asyncio
import logging
import os
from pathlib import Path

import discord
from discord.ext import commands
from dotenv import load_dotenv

from core.database import Database
from core.config import Config
from core.brand import BRAND
from cogs.general import General
from cogs.tickets import Tickets
from cogs.invites import Invites
from cogs.giveaways import Giveaways
from cogs.moderation import Moderation
from cogs.hosting import Hosting
from cogs.status import Status
from cogs.welcome import Welcome

load_dotenv()
Path("data").mkdir(exist_ok=True)
Path("logs").mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("logs/luxanodes.log", encoding="utf-8"),
    ],
)
log = logging.getLogger("luxanodes")

class LuxaNodesBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.members = True
        intents.message_content = True
        intents.presences = True
        intents.guilds = True
        super().__init__(
            command_prefix=Config.prefix,
            intents=intents,
            help_command=None,
            case_insensitive=True,
            activity=discord.Game(name="LuxaNodes • /help"),
        )
        self.db = Database(Config.database_path)

    async def setup_hook(self):
        await self.db.connect()
        cogs = [General, Tickets, Invites, Giveaways, Moderation, Hosting, Status, Welcome]
        for cog in cogs:
            await self.add_cog(cog(self))
        try:
            synced = await self.tree.sync()
            log.info("Synced %s application commands", len(synced))
        except Exception:
            log.exception("Command sync failed")

    async def on_ready(self):
        log.info("Logged in as %s (%s)", self.user, self.user.id)
        print(BRAND["banner"])
        print(BRAND["tagline"])
        await self.change_presence(
            status=discord.Status.online,
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="LuxaNodes • /help",
            ),
        )

    async def close(self):
        await self.db.close()
        await super().close()

async def main():
    token = os.getenv("DISCORD_TOKEN")
    if not token or token == "PASTE_BOT_TOKEN_HERE":
        raise RuntimeError("Set DISCORD_TOKEN in .env")
    bot = LuxaNodesBot()
    async with bot:
        await bot.start(token)

if __name__ == "__main__":
    asyncio.run(main())
