#!/bin/bash
set -e
apt update
apt install -y python3 python3-venv
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
echo "Copy .env.example to .env and set DISCORD_TOKEN."
