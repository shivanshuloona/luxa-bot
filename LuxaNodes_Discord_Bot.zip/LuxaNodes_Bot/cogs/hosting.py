import discord
from discord.ext import commands
from core.brand import embed
from core.config import Config

PLANS = [
    ("Starter", "₹49/mo", "1GB RAM • 1 vCPU • 10GB storage"),
    ("Basic", "₹99/mo", "2GB RAM • 2 vCPU • 20GB storage"),
    ("Pro", "₹199/mo", "4GB RAM • 3 vCPU • 40GB storage"),
    ("Custom", "Contact us", "Custom RAM • CPU • storage • requirements"),
]

class Hosting(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @discord.app_commands.command(name="plans", description="Show LuxaNodes hosting plans.")
    async def plans(self, interaction):
        e = embed("🖥️ LuxaNodes Hosting Plans")
        for name, price, specs in PLANS:
            e.add_field(name=f"{name} — {price}", value=specs, inline=False)
        e.add_field(name="Need something custom?", value=f"Open a ticket or visit {Config.website_url}", inline=False)
        await interaction.response.send_message(embed=e)

    @discord.app_commands.command(name="hosting", description="Show the LuxaNodes hosting menu.")
    async def hosting(self, interaction):
        view = HostingView(Config.website_url)
        e = embed("⚡ LuxaNodes Hosting",
            "Choose what you need below.\n\n"
            "🟢 Minecraft Hosting\n"
            "🔵 VPS / custom infrastructure\n"
            "🟡 Support\n\n"
            "Prices and availability can change; check the current panel before purchasing."
        )
        await interaction.response.send_message(embed=e, view=view)

    @discord.app_commands.command(name="website", description="Get the LuxaNodes website.")
    async def website(self, interaction):
        await interaction.response.send_message(f"🌐 **LuxaNodes:** {Config.website_url}")

class HostingView(discord.ui.View):
    def __init__(self, url):
        super().__init__(timeout=300)
        self.add_item(discord.ui.Button(label="Open Website", url=url, emoji="🌐"))
