import asyncio
import time
import aiohttp
import discord
from discord.ext import commands, tasks
from core.brand import embed, success, error
from core.config import Config

class Status(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.monitor.start()

    def cog_unload(self):
        self.monitor.cancel()

    async def check_url(self, url):
        started = time.perf_counter()
        try:
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url, allow_redirects=True) as r:
                    latency = round((time.perf_counter()-started)*1000)
                    return True, r.status, latency
        except Exception as exc:
            return False, str(exc)[:80], 0

    @tasks.loop(seconds=60)
    async def monitor(self):
        rows = await self.bot.db.fetchall("SELECT * FROM status_targets")
        for row in rows:
            ok, status, latency = await self.check_url(row["url"])
            state = "online" if ok else "offline"
            if state != row["last_state"]:
                await self.bot.db.execute("UPDATE status_targets SET last_state=? WHERE id=?", (state, row["id"]))
                channel = self.bot.get_channel(row["channel_id"])
                if channel:
                    icon = "🟢" if ok else "🔴"
                    await channel.send(embed=embed(f"{icon} {row['name']} Status Changed",
                        f"**State:** `{state}`\n**HTTP:** `{status}`\n**Latency:** `{latency}ms`"))

    @monitor.before_loop
    async def before_monitor(self):
        await self.bot.wait_until_ready()

    @discord.app_commands.command(name="status", description="Check a website/endpoint.")
    async def status(self, interaction, url: str = None):
        target = url or Config.status_url
        await interaction.response.defer()
        ok, status, latency = await self.check_url(target)
        icon = "🟢" if ok else "🔴"
        text = f"{icon} **{'Online' if ok else 'Offline'}**\n\nHTTP: `{status}`\nLatency: `{latency}ms`\nTarget: `{target}`"
        await interaction.followup.send(embed=embed("📡 LuxaNodes Status", text))

    @discord.app_commands.command(name="watch", description="Watch a URL for outages.")
    @discord.app_commands.default_permissions(manage_guild=True)
    async def watch(self, interaction, name: str, url: str):
        await self.bot.db.execute(
            "INSERT INTO status_targets(guild_id,url,name,channel_id,last_state) VALUES(?,?,?,?,?)",
            (interaction.guild.id, url, name, interaction.channel.id, "unknown"),
        )
        await interaction.response.send_message(embed=success(f"Now monitoring **{name}** every 60 seconds."))

    @discord.app_commands.command(name="unwatch", description="Stop monitoring a URL by name.")
    @discord.app_commands.default_permissions(manage_guild=True)
    async def unwatch(self, interaction, name: str):
        await self.bot.db.execute("DELETE FROM status_targets WHERE guild_id=? AND name=?", (interaction.guild.id, name))
        await interaction.response.send_message(embed=success(f"Stopped monitoring **{name}**."))
