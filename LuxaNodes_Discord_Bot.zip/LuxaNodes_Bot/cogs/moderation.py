import discord
from discord.ext import commands
from core.brand import embed, success, error

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def log(self, guild, text):
        from core.config import Config
        if Config.log_channel_id:
            channel = guild.get_channel(Config.log_channel_id)
            if channel:
                await channel.send(embed=embed("📜 Moderation Log", text))

    @discord.app_commands.command(name="warn", description="Warn a member.")
    @discord.app_commands.default_permissions(moderate_members=True)
    async def warn(self, interaction, member: discord.Member, reason: str):
        await self.bot.db.add_warning(interaction.guild.id, member.id, interaction.user.id, reason)
        await self.log(interaction.guild, f"{member.mention} warned by {interaction.user.mention}\n**Reason:** {reason}")
        await interaction.response.send_message(embed=success(f"{member.mention} has been warned.\n**Reason:** {reason}"))

    @discord.app_commands.command(name="warnings", description="Show a member's warnings.")
    @discord.app_commands.default_permissions(moderate_members=True)
    async def warnings(self, interaction, member: discord.Member):
        rows = await self.bot.db.warnings(interaction.guild.id, member.id)
        if not rows:
            return await interaction.response.send_message(embed=embed("📋 Warnings", f"{member.mention} has no warnings."))
        text = "\n".join(f"`#{r['id']}` <t:{int(__import__('datetime').datetime.fromisoformat(r['created_at']).timestamp())}:R> — {r['reason']}" for r in rows[:15])
        await interaction.response.send_message(embed=embed(f"📋 Warnings — {member}", text))

    @discord.app_commands.command(name="clear", description="Delete recent messages.")
    @discord.app_commands.default_permissions(manage_messages=True)
    async def clear(self, interaction, amount: int):
        if amount < 1 or amount > 100:
            return await interaction.response.send_message(embed=error("Amount must be 1-100."), ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        deleted = await interaction.channel.purge(limit=amount)
        await interaction.followup.send(embed=success(f"Deleted `{len(deleted)}` messages."), ephemeral=True)

    @discord.app_commands.command(name="timeout", description="Timeout a member.")
    @discord.app_commands.default_permissions(moderate_members=True)
    async def timeout(self, interaction, member: discord.Member, minutes: int, reason: str = "No reason provided"):
        if minutes < 1 or minutes > 40320:
            return await interaction.response.send_message(embed=error("Minutes must be 1-40320."), ephemeral=True)
        await member.timeout(__import__("datetime").timedelta(minutes=minutes), reason=reason)
        await self.log(interaction.guild, f"{member.mention} timed out for `{minutes}` minutes by {interaction.user.mention}\n{reason}")
        await interaction.response.send_message(embed=success(f"{member.mention} timed out for `{minutes}` minutes."))

    @discord.app_commands.command(name="kick", description="Kick a member.")
    @discord.app_commands.default_permissions(kick_members=True)
    async def kick(self, interaction, member: discord.Member, reason: str = "No reason provided"):
        await member.kick(reason=reason)
        await self.log(interaction.guild, f"{member} kicked by {interaction.user.mention}\n{reason}")
        await interaction.response.send_message(embed=success(f"Removed **{member}**."))

    @discord.app_commands.command(name="ban", description="Ban a member.")
    @discord.app_commands.default_permissions(ban_members=True)
    async def ban(self, interaction, member: discord.Member, reason: str = "No reason provided"):
        await member.ban(reason=reason)
        await self.log(interaction.guild, f"{member} banned by {interaction.user.mention}\n{reason}")
        await interaction.response.send_message(embed=success(f"Banned **{member}**."))
