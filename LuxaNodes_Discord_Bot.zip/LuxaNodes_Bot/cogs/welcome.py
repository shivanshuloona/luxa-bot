import discord
from discord.ext import commands
from core.brand import embed
from core.config import Config

class Welcome(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member):
        channel = member.guild.get_channel(Config.welcome_channel_id) if Config.welcome_channel_id else member.guild.system_channel
        if not channel:
            return
        await channel.send(
            embed=embed("🚀 Welcome to LuxaNodes!",
                        f"Welcome {member.mention}!\n\n"
                        "🖥️ Hosting\n"
                        "🎮 Minecraft community\n"
                        "🎁 Rewards & events\n"
                        "🎟️ Support tickets\n\n"
                        "Run `/help` to explore the bot.")
        )

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        channel = member.guild.get_channel(Config.welcome_channel_id) if Config.welcome_channel_id else member.guild.system_channel
        if channel:
            await channel.send(embed=embed("👋 Member Left", f"**{member}** left the server."))

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return
        # Lightweight anti-spam hook. Keep this intentionally conservative.
        if len(message.content) > 1800:
            try:
                await message.delete()
                await message.channel.send(
                    f"{message.author.mention} please keep messages under 1800 characters.",
                    delete_after=5,
                )
            except discord.HTTPException:
                pass
