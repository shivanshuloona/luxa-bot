import discord
from discord.ext import commands
from core.brand import embed, success

REWARDS = {
    2: "1GB VPS / hosting trial",
    5: "1GB hosting credit",
    10: "2GB hosting credit",
    20: "4GB hosting credit",
    30: "₹100 hosting credit",
    50: "₹250 hosting credit",
}

class Invites(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.cache = {}

    async def cache_guild(self, guild):
        try:
            invites = await guild.invites()
            self.cache[guild.id] = {x.code: x.uses for x in invites}
        except discord.Forbidden:
            self.cache[guild.id] = {}

    @commands.Cog.listener()
    async def on_ready(self):
        for guild in self.bot.guilds:
            await self.cache_guild(guild)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        guild = member.guild
        try:
            before = self.cache.get(guild.id, {})
            after_invites = await guild.invites()
            used = None
            for inv in after_invites:
                if inv.uses > before.get(inv.code, 0):
                    used = inv
                    break
            self.cache[guild.id] = {x.code: x.uses for x in after_invites}
            if used and used.inviter:
                await self.bot.db.add_invite(guild.id, used.inviter.id)
                count = await self.bot.db.get_invites(guild.id, used.inviter.id)
                channel = guild.system_channel
                if channel:
                    await channel.send(embed=embed("👥 New Invite", f"{used.inviter.mention} brought in {member.mention}!\n\n**Verified invites:** `{count}`"))
        except (discord.Forbidden, discord.HTTPException):
            pass

    @discord.app_commands.command(name="invite", description="Show your verified invite count.")
    async def invite(self, interaction):
        count = await self.bot.db.get_invites(interaction.guild.id, interaction.user.id)
        next_reward = next(((n, r) for n, r in sorted(REWARDS.items()) if n > count), None)
        text = f"👥 **Verified invites:** `{count}`\n\n"
        if next_reward:
            n, reward = next_reward
            text += f"Next reward at **{n} invites**: **{reward}**"
        else:
            text += "🏆 You have reached every listed milestone!"
        await interaction.response.send_message(embed=embed("🎁 Invite Rewards", text))

    @discord.app_commands.command(name="leaderboard", description="Show the invite leaderboard.")
    async def leaderboard(self, interaction):
        rows = await self.bot.db.leaderboard(interaction.guild.id, 10)
        if not rows:
            return await interaction.response.send_message(embed=embed("🏆 Invite Leaderboard", "No verified invites yet."))
        lines = []
        for i, row in enumerate(rows, 1):
            member = interaction.guild.get_member(row["user_id"])
            name = member.mention if member else f"<@{row['user_id']}>"
            lines.append(f"**#{i}** {name} — `{row['invites']}` invites")
        await interaction.response.send_message(embed=embed("🏆 Invite Leaderboard", "\n".join(lines)))
