import discord
from discord.ext import commands
from core.brand import embed, error, success, BRAND
from core.config import Config

class General(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @discord.app_commands.command(name="help", description="Show LuxaNodes bot commands.")
    async def help(self, interaction):
        e = embed("⚡ LuxaNodes Command Center",
        "**🎮 Community**\n"
        "`/help` `/ping` `/about` `/serverinfo`\n\n"
        "**🖥️ Hosting**\n"
        "`/hosting` `/plans` `/website`\n\n"
        "**🎟️ Support**\n"
        "`/ticket` `/close`\n\n"
        "**🎁 Growth**\n"
        "`/invite` `/leaderboard` `/giveaway`\n\n"
        "**🛡️ Moderation**\n"
        "`/warn` `/warnings` `/clear` `/timeout` `/kick` `/ban`\n\n"
        "**📡 Status**\n"
        "`/status` `/watch` `/unwatch`"
        )
        e.set_thumbnail(url=interaction.client.user.display_avatar.url)
        await interaction.response.send_message(embed=e)

    @discord.app_commands.command(name="ping", description="Check bot latency.")
    async def ping(self, interaction):
        ms = round(self.bot.latency * 1000)
        await interaction.response.send_message(embed=success(f"🏓 Pong! `{ms}ms`"))

    @discord.app_commands.command(name="about", description="About LuxaNodes.")
    async def about(self, interaction):
        e = embed("🌐 About LuxaNodes",
            "**LuxaNodes** is a Minecraft/hosting-focused community.\n\n"
            "⚡ Affordable hosting\n"
            "🎮 Minecraft community\n"
            "🎁 Rewards & events\n"
            "🛠️ Support & server tools\n\n"
            f"**Website:** {Config.website_url}\n"
            f"**Support:** {Config.support_url}"
        )
        await interaction.response.send_message(embed=e)

    @discord.app_commands.command(name="serverinfo", description="Show this Discord server's information.")
    async def serverinfo(self, interaction):
        g = interaction.guild
        e = embed("🏠 Server Information",
            f"**Name:** {g.name}\n"
            f"**Members:** {g.member_count}\n"
            f"**Channels:** {len(g.channels)}\n"
            f"**Roles:** {len(g.roles)}\n"
            f"**Owner:** <@{g.owner_id}>"
        )
        if g.icon:
            e.set_thumbnail(url=g.icon.url)
        await interaction.response.send_message(embed=e)
