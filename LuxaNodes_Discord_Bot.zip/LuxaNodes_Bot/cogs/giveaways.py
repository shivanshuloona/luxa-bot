import asyncio
import random
import time
import discord
from discord.ext import commands
from core.brand import embed, success, error

class GiveawayView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.entries = set()

    @discord.ui.button(label="Enter Giveaway", style=discord.ButtonStyle.success, emoji="🎁", custom_id="luxanodes:giveaway_enter")
    async def enter(self, interaction, button):
        self.entries.add(interaction.user.id)
        await interaction.response.send_message(
            embed=success("You are entered! Good luck 🍀"),
            ephemeral=True,
        )

class Giveaways(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.active = {}

    @discord.app_commands.command(name="giveaway", description="Create a giveaway.")
    @discord.app_commands.default_permissions(manage_guild=True)
    async def giveaway(self, interaction, duration: int, winners: int, prize: str):
        if duration < 10 or duration > 604800:
            return await interaction.response.send_message(embed=error("Duration must be between 10 and 604800 seconds."), ephemeral=True)
        if winners < 1 or winners > 20:
            return await interaction.response.send_message(embed=error("Winners must be 1-20."), ephemeral=True)
        view = GiveawayView()
        e = embed("🎁 LUXANODES GIVEAWAY",
                  f"**Prize:** {prize}\n"
                  f"**Winners:** `{winners}`\n"
                  f"**Ends:** <t:{int(time.time()+duration)}:R>\n\n"
                  "Click the button below to enter!")
        await interaction.response.send_message(embed=e, view=view)
        msg = await interaction.original_response()
        self.active[msg.id] = (view, winners, prize, msg.channel.id)
        asyncio.create_task(self.finish(msg, view, winners, prize, duration))

    async def finish(self, msg, view, winners, prize, duration):
        await asyncio.sleep(duration)
        ids = list(view.entries)
        random.shuffle(ids)
        selected = ids[:winners]
        channel = msg.channel
        if not selected:
            return await channel.send(embed=embed("🎁 Giveaway Ended", f"Prize: **{prize}**\n\nNo valid entries."))
        mentions = ", ".join(f"<@{x}>" for x in selected)
        await channel.send(embed=embed("🏆 Giveaway Winner", f"Prize: **{prize}**\n\nWinner(s): {mentions} 🎉"))
