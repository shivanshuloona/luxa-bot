import discord
from discord.ext import commands
from core.brand import embed, success, error
from core.config import Config

class TicketView(discord.ui.View):
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(label="Create Ticket", style=discord.ButtonStyle.primary, emoji="🎟️", custom_id="luxanodes:create_ticket")
    async def create_ticket(self, interaction, button):
        guild = interaction.guild
        existing = await self.bot.db.fetchone(
            "SELECT channel_id FROM tickets WHERE guild_id=? AND user_id=?",
            (guild.id, interaction.user.id),
        )
        if existing and guild.get_channel(existing["channel_id"]):
            return await interaction.response.send_message(
                embed=error(f"You already have a ticket: <#{existing['channel_id']}>"),
                ephemeral=True,
            )
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True),
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True),
        }
        if Config.staff_role_id:
            role = guild.get_role(Config.staff_role_id)
            if role:
                overwrites[role] = discord.PermissionOverwrite(view_channel=True, send_messages=True)
        category = guild.get_channel(Config.ticket_category_id) if Config.ticket_category_id else None
        channel = await guild.create_text_channel(
            f"ticket-{interaction.user.name}".lower()[:90],
            overwrites=overwrites,
            category=category if isinstance(category, discord.CategoryChannel) else None,
            reason=f"LuxaNodes ticket for {interaction.user}",
        )
        await self.bot.db.execute(
            "INSERT INTO tickets(guild_id,user_id,channel_id) VALUES(?,?,?)",
            (guild.id, interaction.user.id, channel.id),
        )
        close_view = CloseTicketView(self.bot)
        await channel.send(
            content=f"{interaction.user.mention}",
            embed=embed("🎟️ LuxaNodes Support Ticket",
                "Thanks for contacting LuxaNodes support.\n\n"
                "Please provide:\n"
                "• Your issue\n"
                "• Server/order ID if applicable\n"
                "• Screenshots/logs when useful\n\n"
                "A staff member will respond here."
            ),
            view=close_view,
        )
        await interaction.response.send_message(
            embed=success(f"Ticket created: {channel.mention}"),
            ephemeral=True,
        )

class CloseTicketView(discord.ui.View):
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(label="Close Ticket", style=discord.ButtonStyle.danger, emoji="🔒", custom_id="luxanodes:close_ticket")
    async def close(self, interaction, button):
        await self.bot.db.execute(
            "DELETE FROM tickets WHERE guild_id=? AND channel_id=?",
            (interaction.guild.id, interaction.channel.id),
        )
        await interaction.response.send_message(embed=success("Closing ticket in 5 seconds..."))
        import asyncio
        await asyncio.sleep(5)
        await interaction.channel.delete(reason="LuxaNodes ticket closed")

class Tickets(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        self.bot.add_view(TicketView(self.bot))
        self.bot.add_view(CloseTicketView(self.bot))

    @discord.app_commands.command(name="ticket", description="Open a support ticket.")
    async def ticket(self, interaction):
        existing = await self.bot.db.fetchone(
            "SELECT channel_id FROM tickets WHERE guild_id=? AND user_id=?",
            (interaction.guild.id, interaction.user.id),
        )
        if existing and interaction.guild.get_channel(existing["channel_id"]):
            return await interaction.response.send_message(
                embed=error(f"You already have a ticket: <#{existing['channel_id']}>"),
                ephemeral=True,
            )
        await TicketView(self.bot).create_ticket(interaction, None)

    @discord.app_commands.command(name="ticketpanel", description="Post the support ticket panel.")
    @discord.app_commands.default_permissions(manage_guild=True)
    async def ticketpanel(self, interaction):
        await interaction.channel.send(
            embed=embed("🎟️ LuxaNodes Support Center",
                        "Need help with hosting, billing, setup, or technical issues?\n\n"
                        "Click **Create Ticket** and our team will help you."),
            view=TicketView(self.bot),
        )
        await interaction.response.send_message(embed=success("Ticket panel posted."), ephemeral=True)
