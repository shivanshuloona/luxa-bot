import aiosqlite
from pathlib import Path

class Database:
    def __init__(self, path):
        self.path = path
        self.db = None

    async def connect(self):
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.db = await aiosqlite.connect(self.path)
        self.db.row_factory = aiosqlite.Row
        await self.db.executescript("""
        CREATE TABLE IF NOT EXISTS guild_config (
            guild_id INTEGER PRIMARY KEY,
            welcome_channel INTEGER DEFAULT 0,
            log_channel INTEGER DEFAULT 0,
            ticket_category INTEGER DEFAULT 0,
            staff_role INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS invites (
            guild_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            invites INTEGER DEFAULT 0,
            PRIMARY KEY(guild_id, user_id)
        );
        CREATE TABLE IF NOT EXISTS tickets (
            guild_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            channel_id INTEGER NOT NULL,
            PRIMARY KEY(guild_id, user_id)
        );
        CREATE TABLE IF NOT EXISTS warnings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            moderator_id INTEGER NOT NULL,
            reason TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS giveaways (
            message_id INTEGER PRIMARY KEY,
            channel_id INTEGER NOT NULL,
            guild_id INTEGER NOT NULL,
            prize TEXT NOT NULL,
            winners INTEGER NOT NULL,
            ends_at REAL NOT NULL,
            ended INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS status_targets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id INTEGER NOT NULL,
            url TEXT NOT NULL,
            name TEXT NOT NULL,
            channel_id INTEGER DEFAULT 0,
            last_state TEXT DEFAULT 'unknown'
        );
        """)
        await self.db.commit()

    async def close(self):
        if self.db:
            await self.db.close()

    async def execute(self, query, params=()):
        cur = await self.db.execute(query, params)
        await self.db.commit()
        return cur

    async def fetchone(self, query, params=()):
        cur = await self.db.execute(query, params)
        return await cur.fetchone()

    async def fetchall(self, query, params=()):
        cur = await self.db.execute(query, params)
        return await cur.fetchall()

    async def add_invite(self, guild_id, user_id, amount=1):
        await self.execute(
            """INSERT INTO invites(guild_id,user_id,invites) VALUES(?,?,?)
               ON CONFLICT(guild_id,user_id) DO UPDATE SET invites=invites+excluded.invites""",
            (guild_id, user_id, amount),
        )

    async def get_invites(self, guild_id, user_id):
        row = await self.fetchone(
            "SELECT invites FROM invites WHERE guild_id=? AND user_id=?",
            (guild_id, user_id),
        )
        return row["invites"] if row else 0

    async def leaderboard(self, guild_id, limit=10):
        return await self.fetchall(
            "SELECT user_id, invites FROM invites WHERE guild_id=? ORDER BY invites DESC LIMIT ?",
            (guild_id, limit),
        )

    async def add_warning(self, guild_id, user_id, moderator_id, reason):
        await self.execute(
            "INSERT INTO warnings(guild_id,user_id,moderator_id,reason) VALUES(?,?,?,?)",
            (guild_id, user_id, moderator_id, reason),
        )

    async def warnings(self, guild_id, user_id):
        return await self.fetchall(
            "SELECT * FROM warnings WHERE guild_id=? AND user_id=? ORDER BY id DESC",
            (guild_id, user_id),
        )
