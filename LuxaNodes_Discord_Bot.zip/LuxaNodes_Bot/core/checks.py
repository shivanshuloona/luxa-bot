import discord

def is_mod(interaction: discord.Interaction):
    return interaction.user.guild_permissions.manage_messages

def is_admin(interaction: discord.Interaction):
    return interaction.user.guild_permissions.administrator

def bot_can_act(guild, member):
    if member == guild.owner:
        return False
    me = guild.me
    return bool(me and me.top_role > member.top_role)
