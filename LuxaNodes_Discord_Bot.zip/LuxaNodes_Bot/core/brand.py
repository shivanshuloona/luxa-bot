import discord

BRAND = {
    "name": "LuxaNodes",
    "tagline": "Powering Your Servers. ⚡",
    "color": 0xF4B400,
    "dark": 0x0B0B0F,
    "banner": r"""
╔══════════════════════════════════════════════════════════╗
║  ██╗     ██╗   ██╗██╗  ██╗ █████╗ ███╗   ██╗ ██████╗  ║
║  ██║     ██║   ██║╚██╗██╔╝██╔══██╗████╗  ██║██╔═══██╗ ║
║  ██║     ██║   ██║ ╚███╔╝ ███████║██╔██╗ ██║██║   ██║ ║
║  ██║     ██║   ██║ ██╔██╗ ██╔══██║██║╚██╗██║██║   ██║ ║
║  ███████╗╚██████╔╝██╔╝ ██╗██║  ██║██║ ╚████║╚██████╔╝ ║
║  ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝  ║
║                    L U X A N O D E S                    ║
╚══════════════════════════════════════════════════════════╝
""",
}

def embed(title, description="", *, color=None):
    e = discord.Embed(
        title=title,
        description=description,
        color=color or BRAND["color"],
    )
    e.set_footer(text="LuxaNodes • Powering Your Servers. ⚡")
    return e

def error(message):
    return embed("❌ Something went wrong", message, color=0xED4245)

def success(message):
    return embed("✅ Done", message, color=0x57F287)
