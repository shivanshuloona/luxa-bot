import asyncio
import discord
from functools import wraps
from core.brand import embed, error

def staff_only():
    async def predicate(interaction):
        if interaction.user.guild_permissions.manage_guild:
            return True
        await interaction.response.send_message(
            embed=error("You need **Manage Server** permission for this command."),
            ephemeral=True,
        )
        return False
    return discord.app_commands.check(predicate)

def owner_only():
    async def predicate(interaction):
        from core.config import Config
        if interaction.user.id in Config.owner_ids():
            return True
        await interaction.response.send_message(
            embed=error("This command is restricted to the LuxaNodes owner."),
            ephemeral=True,
        )
        return False
    return discord.app_commands.check(predicate)

async def animated_status(interaction, messages, delay=0.8):
    for i, message in enumerate(messages):
        e = embed("⚡ LuxaNodes", message)
        if i == 0:
            await interaction.response.send_message(embed=e)
        else:
            await asyncio.sleep(delay)
            await interaction.edit_original_response(embed=e)
