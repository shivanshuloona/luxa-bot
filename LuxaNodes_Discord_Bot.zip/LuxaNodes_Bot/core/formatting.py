import discord
from datetime import datetime, timezone

def human_duration(seconds):
    seconds = int(seconds)
    parts = []
    for unit, value in (("d", 86400), ("h", 3600), ("m", 60), ("s", 1)):
        if seconds >= value:
            amount, seconds = divmod(seconds, value)
            parts.append(f"{amount}{unit}")
    return " ".join(parts) or "0s"

def utc_now():
    return datetime.now(timezone.utc)

def member_display(member: discord.Member):
    return member.display_name.replace("@", "@\u200b")

def progress_bar(value, maximum, length=12):
    if maximum <= 0:
        return "░" * length
    ratio = max(0, min(1, value / maximum))
    filled = round(ratio * length)
    return "█" * filled + "░" * (length-filled)
