import os

class Config:
    prefix = os.getenv("PREFIX", "!")
    database_path = os.getenv("DATABASE_PATH", "data/luxanodes.db")
    website_url = os.getenv("WEBSITE_URL", "https://example.com")
    status_url = os.getenv("STATUS_URL", "https://example.com")
    support_url = os.getenv("SUPPORT_URL", "https://discord.gg/YOUR_INVITE")
    log_channel_id = int(os.getenv("LOG_CHANNEL_ID", "0") or 0)
    welcome_channel_id = int(os.getenv("WELCOME_CHANNEL_ID", "0") or 0)
    ticket_category_id = int(os.getenv("TICKET_CATEGORY_ID", "0") or 0)
    staff_role_id = int(os.getenv("STAFF_ROLE_ID", "0") or 0)
    customer_role_id = int(os.getenv("CUSTOMER_ROLE_ID", "0") or 0)
    uptime_interval = int(os.getenv("UPTIME_INTERVAL", "60") or 60)

    @staticmethod
    def owner_ids():
        raw = os.getenv("OWNER_IDS", "")
        return {int(x.strip()) for x in raw.split(",") if x.strip().isdigit()}
