# Commands

## General
`/help` `/ping` `/about` `/serverinfo`

## Hosting
`/plans` `/hosting` `/website`

## Support
`/ticket` `/ticketpanel`

## Growth
`/invite` `/leaderboard`

## Giveaways
`/giveaway <duration> <winners> <prize>`

## Moderation
`/warn` `/warnings` `/clear` `/timeout` `/kick` `/ban`

## Status
`/status` `/watch` `/unwatch`

## Suggested future modules
- Orders/payment webhook integration
- Pterodactyl application API integration
- Customer dashboard
- Automated invoice verification
- Server console controls
- Backup management
