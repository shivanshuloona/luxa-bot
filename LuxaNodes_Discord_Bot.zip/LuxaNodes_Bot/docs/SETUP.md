# Discord Developer Portal setup

1. Create an application in the Discord Developer Portal.
2. Create a bot user and copy the token into `.env`.
3. Enable:
   - Server Members Intent
   - Message Content Intent
4. Invite the bot with the scopes:
   - `bot`
   - `applications.commands`
5. Give only the permissions the bot actually needs.
6. Set IDs in `.env`.
7. Start with `python bot.py`.

For production, do not run the bot with a token pasted into a public file or screenshot.
